import java.io.Serializable;

import javax.swing.DefaultListModel;

public class AddressBook extends DefaultListModel<BuddyInfo> implements Serializable {
	
	@Override
	public boolean equals(Object o) {
		AddressBook other = (AddressBook)o;
		for(int i = 0; i < this.getSize(); i++) {
			if(!other.get(i).equals(this.get(i)))
				return false;
		}
		return true;
	}
}
