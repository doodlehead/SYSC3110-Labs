import java.awt.*;
import java.io.*;

import javax.swing.*;

public class BuddyGUI extends JFrame {
	private JMenuBar menuBar;
	//Model for list
	private AddressBook addressBook;
	private JList<BuddyInfo> buddyListGui;
	
	public BuddyGUI() {
		super("Buddy thing");
		this.setSize(400, 400);
		
		this.menuBar = new JMenuBar();
		JMenu buddyMenu = new JMenu("BuddyInfo");
		JMenu addressMenu = new JMenu("AddressBook");
		
		//BuddyInfo Menu subitems
		JMenuItem addBuddyMenu = new JMenuItem("Add new BuddyInfo");
		addBuddyMenu.addActionListener(e -> {
			this.showBuddyCreation();
		});
		buddyMenu.add(addBuddyMenu);
		
		JMenuItem removeBuddyMenu = new JMenuItem("Remove selected BuddyInfo");
		removeBuddyMenu.addActionListener(e -> {
			if(this.buddyListGui.getSelectedIndex() >= 0) {
				this.addressBook.remove(this.buddyListGui.getSelectedIndex());
				this.buddyListGui.clearSelection();
			} else {
				JOptionPane.showMessageDialog(this, "Error: You have not selected a buddy info to remove");
			}
		});
		buddyMenu.add(removeBuddyMenu);
		
		//AddressBook Menu subitems
		JMenuItem saveAddressBook = new JMenuItem("Save addressBook");
		saveAddressBook.addActionListener(e -> {
			String filename = JOptionPane.showInputDialog(this, "Enter file name");
			if(filename != null) {
				try {
					FileOutputStream fos = new FileOutputStream(filename);
				    ObjectOutputStream oos = new ObjectOutputStream(fos);
				    
				    oos.writeObject(this.addressBook);
				    oos.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		addressMenu.add(saveAddressBook);
		
		JMenuItem importAddressBook = new JMenuItem("Import addressBook");
		importAddressBook.addActionListener(e -> {
			//TODO: Add buddies to AddressBook
			String filename = JOptionPane.showInputDialog(this, "Enter file name");
			if(filename != null) {
				try {
				      FileInputStream fis = new FileInputStream(filename);
				      ObjectInputStream ois = new ObjectInputStream(fis);
				      
				      //Add each BuddyInfo to the existing AddressBook
				      AddressBook temp = (AddressBook) ois.readObject();
			    	  this.addressBook.clear();
				      for(int i = 0; i < temp.size(); i++) {
				    	  this.addressBook.addElement(temp.get(i));
				      }
				      
				      ois.close();
				} catch (IOException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});
		addressMenu.add(importAddressBook);
		
		this.menuBar.add(buddyMenu);
		this.menuBar.add(addressMenu);
		
		//AddressBook Init stuff
		this.addressBook = new AddressBook();
		this.buddyListGui = new JList<BuddyInfo>(addressBook);
		this.add(this.buddyListGui);
		
		this.setJMenuBar(this.menuBar);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	//Show the Buddy creation dialog
	private void showBuddyCreation() {
        JPanel p = new JPanel(new BorderLayout(5,5));

        JPanel labels = new JPanel(new GridLayout(0,1,2,2));
        labels.add(new JLabel("Name", SwingConstants.RIGHT));
        labels.add(new JLabel("Address", SwingConstants.RIGHT));
        labels.add(new JLabel("Phone number", SwingConstants.RIGHT));
        p.add(labels, BorderLayout.WEST);

        JPanel inputs = new JPanel(new GridLayout(0,1,2,2));
        JTextField name = new JTextField();
        inputs.add(name);
        JTextField address = new JTextField();
        inputs.add(address);
        JTextField phoneNum = new JTextField();
        inputs.add(phoneNum);
        p.add(inputs, BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(this, p, "Create Buddy", JOptionPane.OK_CANCEL_OPTION);
        if(result == JOptionPane.OK_OPTION) {
        	this.addressBook.addElement(new BuddyInfo(name.getText(), 
        			address.getText(), phoneNum.getText()));
        }
	}
	public static void main(String[] args) {
		BuddyGUI g = new BuddyGUI();
	}
}
