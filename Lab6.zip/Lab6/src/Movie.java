
public class Movie {
	private String name;
	
	public Movie(String name) {
		this.name = name;
	}
}
