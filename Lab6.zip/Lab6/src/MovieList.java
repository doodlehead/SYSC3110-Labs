import java.util.ArrayList;

public class MovieList extends ArrayList<Movie>{
	
}
