package buddyInfo;

import java.util.ArrayList;

import javax.swing.DefaultListModel;

public class AddressBook extends ArrayList<BuddyInfo> {
}
