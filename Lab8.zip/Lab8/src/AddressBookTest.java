import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.junit.jupiter.api.Test;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AddressBookTest {
	
	@Test
	public void serializedDataIsTheSame() {
		AddressBook temp = new AddressBook();
		BuddyInfo buddy = new BuddyInfo("Carl", "123 str", "234-234-1234");
		temp.addElement(buddy);
		
		//Write to file
	    try {
			FileOutputStream fos = new FileOutputStream("TestAddressBook");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(temp);
			
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    //Read from file

	    try {
	    	FileInputStream fis = new FileInputStream("TestAddressBook");
	    	ObjectInputStream ois = new ObjectInputStream(fis);
	    	AddressBook comp = (AddressBook) ois.readObject();
	    	assertTrue(comp.equals(temp));
	    	
	    	ois.close();
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}