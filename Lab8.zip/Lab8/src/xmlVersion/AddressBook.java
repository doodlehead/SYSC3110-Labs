package xmlVersion;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.swing.DefaultListModel;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class AddressBook extends DefaultListModel<BuddyInfo> implements Serializable {
	
	@Override
	public boolean equals(Object o) {
		AddressBook other = (AddressBook)o;
		for(int i = 0; i < this.getSize(); i++) {
			if(!other.get(i).equals(this.get(i)))
				return false;
		}
		return true;
	}
	
	public String toXML() {
		StringBuilder sb = new StringBuilder();
		sb.append("<AddressBook>");
		
		for(int i = 0; i < this.getSize(); i++) {
			sb.append(this.get(i).toXML());
		}
		
		sb.append("</AddressBook>");
		
		return sb.toString();
	}
	
	public static void exportToXmlFile(String filename, AddressBook addressBook) {
		try {
			//Write as XML file
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			
			writer.write(addressBook.toXML());
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	
	public static AddressBook importFromXmlFile(String filename) throws ParserConfigurationException, SAXException, FileNotFoundException, IOException {
		SAXParserFactory spf = SAXParserFactory.newInstance();
		SAXParser s = spf.newSAXParser();
		
		CustomHandler dh = new CustomHandler();
		
		s.parse(new FileInputStream(filename), dh);
		return dh.getAddressBook();
	}
}

enum ReadState {
	ADDRESS_BOOK, BUDDY_INFO, BUDDY_NAME, BUDDY_ADDRESS, BUDDY_PHONENUM
}

class CustomHandler extends DefaultHandler {
	private ReadState state;
	private AddressBook book = new AddressBook();
	private BuddyInfo temp = new BuddyInfo("", "", "");
	
	public AddressBook getAddressBook() {
		return this.book;
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) {
		switch(qName) {
		case "AddressBook":
			this.state = ReadState.ADDRESS_BOOK;
			break;
		case "BuddyInfo":
			this.state = ReadState.BUDDY_INFO;
			break;
		case "name":
			this.state = ReadState.BUDDY_NAME;
			break;
		case "address":
			this.state = ReadState.BUDDY_ADDRESS;
			break;
		case "phoneNumber":
			this.state = ReadState.BUDDY_PHONENUM;
			break;
		default:
			throw new IllegalArgumentException("Illegal tag found: " + qName);
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) {
		//Create the BuddyInfo because it's done
		if(qName.equals("BuddyInfo")) {
			this.book.addElement(this.temp);
			this.temp = new BuddyInfo("", "", "");
		}
		this.state = null;
	}
	
	@Override
	public void characters(char[] ch, int start, int length) {
		if(state == null) {
			throw new IllegalStateException("Invalid XML");
		} else if(state == ReadState.BUDDY_NAME) {
			this.temp.setName(new String(ch, start, length));
		} else if(state == ReadState.BUDDY_ADDRESS) {
			this.temp.setAddress(new String(ch, start, length));
		} else if(state == ReadState.BUDDY_PHONENUM) {
			this.temp.setPhoneNumber(new String(ch, start, length));
		}
	}
}

