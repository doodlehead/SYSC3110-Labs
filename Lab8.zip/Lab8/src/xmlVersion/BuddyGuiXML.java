package xmlVersion;

import java.awt.*;
import java.io.*;

import javax.swing.*;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

public class BuddyGuiXML extends JFrame {
	private JMenuBar menuBar;
	//Model for list
	private AddressBook addressBook;
	private JList<BuddyInfo> buddyListGui;
	
	public BuddyGuiXML() {
		super("Buddy thing");
		this.setSize(400, 400);
		
		this.menuBar = new JMenuBar();
		JMenu buddyMenu = new JMenu("BuddyInfo");
		JMenu addressMenu = new JMenu("AddressBook");
		
		//BuddyInfo Menu subitems
		JMenuItem addBuddyMenu = new JMenuItem("Add new BuddyInfo");
		addBuddyMenu.addActionListener(e -> {
			this.showBuddyCreation();
		});
		buddyMenu.add(addBuddyMenu);
		
		JMenuItem removeBuddyMenu = new JMenuItem("Remove selected BuddyInfo");
		removeBuddyMenu.addActionListener(e -> {
			if(this.buddyListGui.getSelectedIndex() >= 0) {
				this.addressBook.remove(this.buddyListGui.getSelectedIndex());
				this.buddyListGui.clearSelection();
			} else {
				JOptionPane.showMessageDialog(this, "Error: You have not selected a buddy info to remove");
			}
		});
		buddyMenu.add(removeBuddyMenu);
		
		//AddressBook Menu subitems
		JMenuItem saveAddressBook = new JMenuItem("Save addressBook");
		saveAddressBook.addActionListener(e -> {
			String filename = JOptionPane.showInputDialog(this, "Enter file name");
			if(filename != null) {
				AddressBook.exportToXmlFile(filename, this.addressBook);
			}
		});
		addressMenu.add(saveAddressBook);
		
		JMenuItem importAddressBook = new JMenuItem("Import addressBook");
		importAddressBook.addActionListener(e -> {
			//TODO: Add buddies to AddressBook
			String filename = JOptionPane.showInputDialog(this, "Enter file name");
			if(filename != null) {
				try {
					AddressBook temp = AddressBook.importFromXmlFile(filename);
					this.addressBook.clear();
					for(int i = 0; i < temp.getSize(); i++) {
						this.addressBook.addElement(temp.get(i));
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		addressMenu.add(importAddressBook);
		
		this.menuBar.add(buddyMenu);
		this.menuBar.add(addressMenu);
		
		//AddressBook Init stuff
		this.addressBook = new AddressBook();
		this.buddyListGui = new JList<BuddyInfo>(addressBook);
		this.add(this.buddyListGui);
		
		this.setJMenuBar(this.menuBar);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	//Show the Buddy creation dialog
	private void showBuddyCreation() {
        JPanel p = new JPanel(new BorderLayout(5,5));

        JPanel labels = new JPanel(new GridLayout(0,1,2,2));
        labels.add(new JLabel("Name", SwingConstants.RIGHT));
        labels.add(new JLabel("Address", SwingConstants.RIGHT));
        labels.add(new JLabel("Phone number", SwingConstants.RIGHT));
        p.add(labels, BorderLayout.WEST);

        JPanel inputs = new JPanel(new GridLayout(0,1,2,2));
        JTextField name = new JTextField();
        inputs.add(name);
        JTextField address = new JTextField();
        inputs.add(address);
        JTextField phoneNum = new JTextField();
        inputs.add(phoneNum);
        p.add(inputs, BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(this, p, "Create Buddy", JOptionPane.OK_CANCEL_OPTION);
        if(result == JOptionPane.OK_OPTION) {
        	this.addressBook.addElement(new BuddyInfo(name.getText(), 
        			address.getText(), phoneNum.getText()));
        }
	}
	public static void main(String[] args) {
		BuddyGuiXML g = new BuddyGuiXML();
	}
}
